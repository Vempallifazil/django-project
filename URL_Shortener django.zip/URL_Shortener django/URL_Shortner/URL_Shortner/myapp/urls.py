
from django.contrib import admin
from django.urls import path,include
from . import views


urlpatterns = [
    path('hello', views.hello_world),
    path('task', views.task),
    path('', views.home_page),
    path('all-analytics', views.all_analytics),
    path('<slug:short_url>', views.redirect_url), 
    path('generate_qr_code/<slug:short_url>/', views.generate_qr_code, name='generate_qr_code'),
]
